from flask import Flask, render_template

app = Flask(__name__)

# untuk bikin rute home
@app.route('/', methods=['GET', 'POST'])
def home():
    return render_template("home.html")

# untuk bikin rute klik tombol about
@app.route('/visualization', methods=['GET', 'POST'])
def about():
    return render_template('visualization.html')

# untuk bikin rute klik tombol dataset
@app.route('/dataset', methods=['GET', 'POST'])
def dataset():
    return render_template('dataset.html')

if __name__ == '__main__':
    app.run(debug=True)